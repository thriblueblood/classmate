import { Typography, MenuItem, TextField,Box, Grid } from "@mui/material";
import { useState } from "react";
import { ThemeProvider } from '@emotion/react';
import theme from "../ui/Theme";
import "./SubjectDetailPage.css";

const weekSubject = [
  {
    number: 1,
    date: "12/12/21",
  },
  {
    number: 2,
    date: "24/12/21",
  },
];

export default function SubjectDetail() {
    const [tab, setTab] = useState(1);
  
    const changeTab = (index) => {
      setTab(index);
    };
    return (
        <div style={{padding:"2%",width:'90%'}}>
        <Typography variant="h2">Python</Typography>
        <Typography variant="subtitle2">Professor : Alex</Typography>
        <Typography variant="subtitle2">
          Class time : 13:00 PM - 15.00 PM
        </Typography>
        <Typography variant="subtitle2">
          Mid-term examination : 30 Feb 2035, 13.00 AM - 15.00 PM
        </Typography>
        <Typography variant="subtitle2">
          Final examination : 30 April 2035, 13.00 AM - 15.00 PM
        </Typography>
        <br></br>
        <div>
  <div className="block_tab">
          <div
            onClick={() => changeTab(1)}
            className={tab === 1 ? "tabs active-tabs" : "tabs"}
          >
            Materials
          </div>
          <div
            onClick={() => changeTab(2)}
            className={tab === 2 ? "tabs active-tabs" : "tabs"}
          >
            Assignments{" "}
          </div>
          <div
            onClick={() => changeTab(3)}
            className={tab === 3 ? "tabs active-tabs" : "tabs"}
          >
            Notes
          </div>
          {/* <div className="drop_down" sx={{borderRadius:"10px"}}>
            <TextField select borderRadius = "29">
              {weekSubject.map((week) => (
                <MenuItem key={week.number} value={week.number}>
                  {"Week " + week.number + "," + week.date}
                </MenuItem>
              ))}
            </TextField>
          </div> */}
        </div>
        <div className="content_container">
        <Grid container columns={{ xs: 4, sm: 8, md: 12 }}>
            {Array.from(Array(6)).map((_, index) => (
                <Grid item xs={2} sm={4} md={4} key={index}>
                <Typography>S</Typography>
        </Grid>
        ))}
        </Grid>
        </div>
        </div>
        </div>
    );
  }
  
