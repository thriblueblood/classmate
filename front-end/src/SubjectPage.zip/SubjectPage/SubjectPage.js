import { Card, CardContent, CardActions,Stack, Box, Typography, Divider,Button} from "@mui/material";
import { ThemeProvider } from '@emotion/react';
import { Link } from 'react-router-dom';
import theme from "../ui/Theme";
import SearchBar from "../Components/SearchBar.js";
import AddIcon from '@mui/icons-material/Add';

import Slide from '@mui/material/Slide';

import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import * as React from "react";
import AddSubjectPopUp from "./AddSubjectPopUp";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const subjects = [
    {
      key: 1,
      title: "Python",
      professor: "Alex",
    },
    {
      key: 2,
      title: "C",
      professor: "Taylor",
    },
    {
      key: 3,
      title: "C++",
      professor: "Jeff",
    },
  ];

export default function SubjectPage(){

  const [dialogOpen, setDialogOpen] = React.useState(false);

  const handleDialogOpen = () => {
    setDialogOpen(true);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
  };

    return(
        <ThemeProvider theme={theme}>
        <Box sx={{padding:"1%"}}> 
        <Stack direction="row">
        <Typography variant="h2" fontSize="1.25rem">List of subjects</Typography>
        </Stack>
      <Divider/>
      <Box sx={{marginBottom:"1%"}}>
      <SearchBar/>
      </Box>
        <Box sx={{display:"flex"}}>
        <Button style={{backgroundColor:"green", margin:"1% 0%",marginLeft:"auto"}}variant="contained" startIcon={<AddIcon/>} onClick={handleDialogOpen}>
                Add Subject
            </Button>
        </Box>
    {subjects.map((subject) => (
        <div>
        <Link to={`/main/room/subject/${subject.key}`} style={{textDecoration:"none"}}>
        <Card sx={{backgroundColor:"secondary.main"}}>
              <CardContent sx={{width:"100%"}}>
                <Typography variant="h3" fontSize="2rem" color="primary.dark" >{subject.title}</Typography>
                <Typography variant="h4" fontSize="1rem" color="primary.main">{subject.professor}</Typography>
              </CardContent>
          </Card>
          </Link>
          <br />
        </div>
      ))}
        </Box>
      
      {/* Dialog */}
      <Dialog
        open={dialogOpen}
        TransitionComponent={Transition}
        keepMounted
        onClose={handleDialogClose}
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle sx={{textAlign:"center"}}>{"Add Subject to your room"}</DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
          <AddSubjectPopUp/>
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose}>Cancel</Button>
          <Button onClick={handleDialogClose}>Submit</Button>
        </DialogActions>
      </Dialog>

        </ThemeProvider>
    );
}